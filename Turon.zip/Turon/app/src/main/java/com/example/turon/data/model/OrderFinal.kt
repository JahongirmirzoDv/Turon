package com.example.turon.data.model

data class OrderFinal(
var client:String,
var date:String,
var carNum:String,
var phoneNum:String,

)