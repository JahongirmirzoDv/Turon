package com.example.turon.data.model

data class ActiveTurn(
    val id: Int,
    val mijoz:String,
    val car_number:String,
    val driver_phone:String,
    val date:String

)
