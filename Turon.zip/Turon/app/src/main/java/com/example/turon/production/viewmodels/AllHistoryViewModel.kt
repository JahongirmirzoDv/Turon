package com.example.turon.production.viewmodels

import androidx.lifecycle.ViewModel
import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import com.example.turon.data.api.ApiService
import com.example.turon.data.data.*
import com.example.turon.data.model.HistoryProData
import com.example.turon.data.model.OrderHistory
import kotlinx.coroutines.flow.Flow

class AllHistoryViewModel(private val apiService: ApiService) : ViewModel() {
    fun getProductionPagination(): Flow<PagingData<HistoryProData>> {
        return Pager(
            config = PagingConfig(
                pageSize = 15,
                enablePlaceholders = false
            ),
            pagingSourceFactory = { ProductionDataSource(apiService) }
        ).flow
    }

    fun getAcceptancePagination(userId:Int): Flow<PagingData<HistoryProData>> {
        return Pager(
            config = PagingConfig(
                pageSize = 15,
                enablePlaceholders = false
            ),
            pagingSourceFactory = { AcceptanceDataSource(apiService,userId) }
        ).flow
    }

    fun getOrderPagination(text: String,userId: Int): Flow<PagingData<OrderHistory>> {
        return Pager(
            config = PagingConfig(
                pageSize = 15,
                enablePlaceholders = false
            ),
            pagingSourceFactory = { OrderHistoryDataSource(apiService,text,userId) }
        ).flow
    }

    fun getReturnedPagination(): Flow<PagingData<OrderHistory>> {
        return Pager(
            config = PagingConfig(
                pageSize = 15,
                enablePlaceholders = false
            ),
            pagingSourceFactory = { ReturnedDataSource(apiService) }
        ).flow
    }

    fun getReturnedProPagination(): Flow<PagingData<HistoryProData>> {
        return Pager(
            config = PagingConfig(
                pageSize = 15,
                enablePlaceholders = false
            ),
            pagingSourceFactory = { ReturnedProDataSource(apiService) }
        ).flow
    }

}