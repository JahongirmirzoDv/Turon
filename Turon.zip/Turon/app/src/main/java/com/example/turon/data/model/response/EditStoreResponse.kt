package com.example.turon.data.model.response

data class EditStoreResponse(
    var success: Boolean,
    var message: String,
    var error: String,
    var data: String)
