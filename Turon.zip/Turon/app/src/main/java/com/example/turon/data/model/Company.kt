package com.example.turon.data.model

data class Company(
    var id: Int,
    var name:String
    )