package com.example.turon.data.model

data class BagRoom(
    var id:Int,
    var quantity:Int,
    var type:Type,
    var price:Float,
    var tegirmon:Int
)
