package com.example.turon.data.model.response

class BagTypeResponse {
}