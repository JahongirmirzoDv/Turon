package com.example.turon.data.model

data class AcceptHistory(
    val productName:String,
    val date:String,
    val zavod:String,
    val massa:String,
    val countFlags:String

)
