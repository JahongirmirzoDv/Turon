package com.example.turon.data.model

data class AcceptProduct(
    var ID:String,
    var wagonNumber:String,
    var brutto:String,
    var tara:String
)
