package com.example.turon.data.model

class AcceptProductScanner (
    var productName:String,
    var crCode:Long,
    var isSelected :Boolean= false
)