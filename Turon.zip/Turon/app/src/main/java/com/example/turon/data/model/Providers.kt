package com.example.turon.data.model

data class Providers(
    var id: Int,
    var name: String
)