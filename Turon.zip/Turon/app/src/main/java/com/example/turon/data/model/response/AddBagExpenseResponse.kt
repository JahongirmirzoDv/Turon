package com.example.turon.data.model.response

data class AddBagExpenseResponse(
    var success: Boolean
)
