package com.example.turon.data.model.response

data class CargoManResponse(
    var success:Boolean,
    val `data`: List<TegirmonData>,
)
