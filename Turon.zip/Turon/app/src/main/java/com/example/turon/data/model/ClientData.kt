package com.example.turon.data.model

class ClientData(
    val maxsulot:String,
    val maxsulot_turi:String,
    val qop_soni:Double,
    val umumiy_massa:Double
)
