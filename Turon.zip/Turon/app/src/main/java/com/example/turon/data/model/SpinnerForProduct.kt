package com.example.turon.data.model

data class SpinnerForProduct(
    var id:Int,
    var name:String,
    var accept:Boolean=false

)
