package com.example.turon.data.model

data class Customer(
    val id:Int,
    val name:String,
    val phone:String
)
