package com.example.turon.data.model

data class Turn(
    var id:Int,
    var mijoz:String,
    var sana:String

)