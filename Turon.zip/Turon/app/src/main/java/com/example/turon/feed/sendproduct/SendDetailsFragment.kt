package com.example.turon.feed.sendproduct

import android.app.AlertDialog
import android.app.Dialog
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.Button
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import androidx.core.os.bundleOf
import androidx.core.view.isVisible
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.example.turon.App
import com.example.turon.R
import com.example.turon.adapter.OrderBaskedAdapter
import com.example.turon.adapter.OrderDetailsAdapter
import com.example.turon.data.api.ApiClient
import com.example.turon.data.api.ApiHelper
import com.example.turon.data.api.ApiService
import com.example.turon.data.model.OrderBasked
import com.example.turon.data.model.SharedViewModel
import com.example.turon.data.model.factory.FeedSendViewModelFactory
import com.example.turon.data.model.repository.state.UIState
import com.example.turon.data.model.response.OrderDetailsData
import com.example.turon.databinding.DialogItemBinding
import com.example.turon.databinding.FragmentAcceptanceDetails2Binding
import com.example.turon.databinding.FragmentSendDetailsBinding
import com.example.turon.utils.SharedPref
import dmax.dialog.SpotsDialog
import kotlinx.coroutines.flow.collect
import java.lang.Exception


class SendDetailsFragment : Fragment(), OrderBaskedAdapter.OnOrderBaskedClickListener {
    private var _binding: FragmentSendDetailsBinding? = null
    private val binding get() = _binding!!
    private lateinit var progressDialog: AlertDialog
    private lateinit var orderList: ArrayList<OrderBasked>
    private lateinit var adapter: OrderBaskedAdapter
    private var orderId: Int? = null
    private var clientNames: String? = null
    private var userId: Int? = null
    private val sharedViewModel: SharedViewModel by activityViewModels()
    private val viewModel: SendProductViewModel by viewModels {
        FeedSendViewModelFactory(
            ApiHelper(ApiClient.createService(ApiService::class.java, requireContext()))
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        orderId = requireArguments().getInt("orderId")
        clientNames = requireArguments().getString("clientName")
        userId = SharedPref(requireContext()).getUserId()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentSendDetailsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initAction()
        binding.appBarTitle.text = clientNames
        setupUI()
        progressDialog.show()
    }

    private fun setupUI() {
        progressDialog = SpotsDialog.Builder()
            .setContext(requireContext())
            .setMessage("Yuklanmoqda")
            .setCancelable(false)
            .build()
        orderList = ArrayList()
        binding.recyclerSendDetails.setHasFixedSize(true)

        getOrderDetails()

    }

    private fun getOrderDetails() {
        val userId = SharedPref(requireContext()).getUserId()
        lifecycleScope.launchWhenStarted {
            viewModel.getOrderDetails(userId, orderId!!)
            viewModel.orderDetailsState.collect {
                when (it) {
                    is UIState.Success -> {
                        orderList.clear()
                        orderList.addAll(it.data)
                        setRecycler()
                        progressDialog.dismiss()
                    }
                    is UIState.Error -> {
                        progressDialog.dismiss()
                        Toast.makeText(requireContext(), it.error, Toast.LENGTH_SHORT).show()
                    }
                    is UIState.Loading, UIState.Empty -> Unit

                }
            }

        }
    }

    private fun setRecycler(){
            with(binding) {
                if (orderList.isEmpty()){
                    recyclerSendDetails.isVisible = false
                    infoTxt.isVisible = true
                }else{
                    recyclerSendDetails.isVisible = true
                    infoTxt.isVisible = false
                }

            }

        adapter = OrderBaskedAdapter(orderList, this@SendDetailsFragment)
        binding.recyclerSendDetails.adapter = adapter
    }

    private fun initAction() {
        binding.menu.setOnClickListener {
            val popupMenu = PopupMenu(requireContext(), it)
            popupMenu.setOnMenuItemClickListener {
                when (it.itemId) {
                    R.id.sendHistory -> {
                        findNavController().navigate(R.id.feedSendHistoryFragment)
                        true
                    }
                    R.id.brandBalance -> {
                        findNavController().navigate(R.id.brandBalanceFragment)
                        true
                    }
                    else -> false
                }
            }
            popupMenu.inflate(R.menu.option_menu_balance)
            try {
                val fieldMPopup = PopupMenu::class.java.getDeclaredField("mPopup")
                fieldMPopup.isAccessible = true
                val mPopup = fieldMPopup.get(popupMenu)
                mPopup.javaClass
                    .getDeclaredMethod("setForceShowIcon", Boolean::class.java)
                    .invoke(mPopup, true)
            } catch (e: Exception) {
                Log.d("TAG", "Error show menu icon")
            } finally {
                popupMenu.show()
            }
        }
    }

    override fun onItemClickOrderBasked(data: OrderBasked) {
        val bundle = bundleOf(
            "orderId" to orderId
        )
        findNavController().navigate(
            R.id.action_sendDetailsFragment_to_sendProductScanFragment,
            bundle
        )
    }


}