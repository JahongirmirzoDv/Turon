package com.example.turon.data.model

class EditScales {
    var wagon_id: Int = 0
    var brutto: Int = 0
    var tara: Int = 0
}