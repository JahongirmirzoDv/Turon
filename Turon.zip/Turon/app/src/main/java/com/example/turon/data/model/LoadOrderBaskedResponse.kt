package com.example.turon.data.model

data class LoadOrderBaskedResponse(
    val success:Boolean,
    val message:String,
    val status:Boolean,
    val counter:Int


)
