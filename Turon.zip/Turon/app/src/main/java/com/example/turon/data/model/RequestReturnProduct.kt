package com.example.turon.data.model

data class RequestReturnProduct(
    val user:Int,
    val izoh:String,
    val code:List<Long>
)
