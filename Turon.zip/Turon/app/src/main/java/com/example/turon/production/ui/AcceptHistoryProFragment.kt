package com.example.turon.production.ui

import android.app.AlertDialog
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.paging.LoadState
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.turon.R
import com.example.turon.adapter.AcceptWithScannerAdapter
import com.example.turon.adapter.AdvertLoadStateAdapter
import com.example.turon.adapter.OnScanListenerT
import com.example.turon.adapter.ProductionHistoryAdapter
import com.example.turon.data.api.ApiClient
import com.example.turon.data.api.ApiClient.apiService
import com.example.turon.data.api.ApiHelper
import com.example.turon.data.api.ApiService
import com.example.turon.data.model.AcceptProductScanner
import com.example.turon.data.model.HistoryProData
import com.example.turon.data.model.factory.AllHistoryViewModelFactory
import com.example.turon.data.model.factory.ProductionViewModelFactory
import com.example.turon.data.model.repository.state.UIState
import com.example.turon.databinding.FragmentAcceptHistoryProBinding
import com.example.turon.production.viewmodels.AllHistoryViewModel
import com.example.turon.production.viewmodels.ProductionViewModel
import dmax.dialog.SpotsDialog
import kotlinx.android.synthetic.main.fragment_product_history.*
import kotlinx.coroutines.flow.collect


class AcceptHistoryProFragment : Fragment() {
    private var _binding: FragmentAcceptHistoryProBinding? = null
    private val binding get() = _binding!!
    private lateinit var adapterHistory: ProductionHistoryAdapter
    private val list by lazy { ArrayList<HistoryProData>() }
    private lateinit var progressDialog: AlertDialog



    private val viewModel: AllHistoryViewModel by viewModels{
       AllHistoryViewModelFactory(
           ApiClient.createService(ApiService::class.java,requireContext())
       )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAcceptHistoryProBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupUI()

    }

    private fun setupUI() {
        progressDialog = SpotsDialog.Builder()
            .setContext(requireContext())
            .setMessage("Yuklanmoqda")
            .setCancelable(false)
            .build()
        setRecycler()
        getHistoryPro()


    }

    private fun setRecycler() {
        adapterHistory=ProductionHistoryAdapter()
        binding.recyclerHistoryPro.apply {
            layoutManager=LinearLayoutManager(requireContext())
            adapter=adapterHistory.withLoadStateHeaderAndFooter(
                header=AdvertLoadStateAdapter{adapterHistory.retry()},
                footer=AdvertLoadStateAdapter{adapterHistory.retry()}
            )
        }

        adapterHistory.addLoadStateListener {loadStates ->

            when (loadStates.refresh) {
                is LoadState.NotLoading -> {
                    progressDialog.dismiss()
                }
                is LoadState.Loading -> {
                    progressDialog.show()
                }
                is LoadState.Error -> {
                    progressDialog.dismiss()
                }
            }
        }
    }


    private fun getHistoryPro() {
        viewLifecycleOwner.lifecycleScope.launchWhenStarted {
            val response=viewModel.getProductionPagination()
            response.collect {
                adapterHistory.submitData(it)
            }
        }
    }


}